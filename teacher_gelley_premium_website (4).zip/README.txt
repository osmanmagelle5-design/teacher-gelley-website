TEACHER GELLEY PREMIUM WEBSITE

Included:
- Actual Teacher Gelley photo
- Teacher Gelley logo
- English / 中文 language switcher
- Digital Shop section
- Sample digital products and prices
- Buy Now buttons ready for Payhip/product checkout links
- Live class packages
- Free Trial CTA
- WhatsApp / WeChat / Online Booking buttons
- Contact form using osmanmagelle5@gmail.com
- Mobile responsive design

IMPORTANT:
1. Replace the four https://payhip.com/ links in index.html with the direct checkout URLs for your actual products.
2. Replace the WhatsApp https://wa.me/ link with your WhatsApp link, e.g. https://wa.me/COUNTRYCODEPHONENUMBER
3. Replace the WeChat button with your WeChat QR code/link if desired.
4. Replace the Online Booking button with your booking URL (Calendly, Google Calendar appointment schedule, etc.).

Open index.html to preview the site.
